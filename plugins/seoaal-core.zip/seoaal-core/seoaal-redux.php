<?php
	
class SeoaalRedux{
	function __construct(){
		define( 'SEOAAL_CORE_REDUX', plugin_dir_path(__FILE__) . 'admin/ReduxCore' );
	}
	
	function seoaalReduxInit(){
		require_once( SEOAAL_CORE_REDUX . '/framework.php' );
		require_once( SEOAAL_CORE_DIR . 'admin/theme-config/config.php' );
	}
}
$seoaal_redux = new SeoaalRedux();
$seoaal_redux->seoaalReduxInit();