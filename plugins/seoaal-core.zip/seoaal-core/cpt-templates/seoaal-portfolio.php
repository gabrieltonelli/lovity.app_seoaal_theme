<?php
// Portfolio Content
$t = new SeoaalCPTElements();
$p_layout = $t->seoaalCPTPortfolioLayout();
while ( have_posts() ) : the_post();
	$sticky_col = get_post_meta( get_the_ID(), 'seoaal_portfolio_sticky', true );
	$sticky_lclass = $sticky_rclass = '';
	if( !empty( $sticky_col ) && $sticky_col != 'none' ){
		$sticky_lclass = $sticky_col == 'left' ? ' seoaal-sticky-obj' : '';
		$sticky_rclass = $sticky_col == 'right' ? ' seoaal-sticky-obj' : '';
		wp_enqueue_script( 'sticky-kit' );
	}
?>
	<?php if( $p_layout == '1' ) : ?>
		<div class="portfolio-single portfolio-model-1">
			<div class="row">
				
				<div class="col-sm-8">
					<div class="portfolio-format<?php echo esc_attr( $sticky_lclass ); ?>">
						<?php $t->seoaalCPTPortfolioFormat(); ?>
					</div>
					<div class="portfolio-info-wrap">
						<?php $t->seoaalCPTPortfolioTitle(); ?>
						<?php $t->seoaalCPTPortfolioContent(); ?>						
					</div>
				</div>
				<div class="col-sm-4">
					<div class="portfolio-info<?php echo esc_attr( $sticky_rclass ); ?>">
						<?php $t->seoaalCPTMeta(); ?>
					</div>
				</div><!-- .col -->
		
			</div><!-- .row -->
			<div class="row">
				<?php $t->seoaalCPTNav(); ?>
			</div><!-- .row -->
		</div><!-- .portfolio-single -->
	<?php elseif( $p_layout == '2' ) : ?>
		<div class="portfolio-single portfolio-model-2">
			<div class="row">
			
				<div class="col-sm-12">
					<div class="portfolio-format">
						<?php $t->seoaalCPTPortfolioFormat(); ?>
					</div>
				</div>
				
			</div><!-- .row -->
			<div class="row portfolio-details">
				<div class="col-sm-8">
					<div class="portfolio-content-wrap<?php echo esc_attr( $sticky_lclass ); ?>">
						<?php $t->seoaalCPTPortfolioTitle(); ?>
						<?php $t->seoaalCPTPortfolioContent(); ?>
					</div>
				</div>
				
				<div class="col-sm-4">
					<div class="portfolio-meta-wrap<?php echo esc_attr( $sticky_rclass ); ?>">
						<?php $t->seoaalCPTMeta(); ?>
					</div>
				</div>
				
			</div><!-- .row -->
			
			<div class="row">
				<?php $t->seoaalCPTNav(); ?>
			</div>
			
		</div><!-- .portfolio-single -->
	<?php elseif( $p_layout == '3' ) : ?>
		<div class="portfolio-single portfolio-model-3">
			<div class="row">
				
				<div class="col-sm-4">
					<div class="portfolio-info<?php echo esc_attr( $sticky_rclass ); ?>">
						<?php $t->seoaalCPTMeta(); ?>
						<?php $t->seoaalCPTNav(); ?>
					</div>
				</div><!-- .col -->
				<div class="col-sm-8">
					<div class="portfolio-format<?php echo esc_attr( $sticky_lclass ); ?>">
						<?php $t->seoaalCPTPortfolioFormat(); ?>
					</div>
					<div class="portfolio-info-wrap">
						<?php $t->seoaalCPTPortfolioTitle(); ?>
						<?php $t->seoaalCPTPortfolioContent(); ?>
					</div>
				</div>
		
			</div><!-- .row -->
		</div><!-- .portfolio-single -->
	<?php elseif( $p_layout == '4' ) : ?>
		<div class="portfolio-single portfolio-model-4">
			<div class="row">
				
				<div class="col-sm-12">
					<div class="portfolio-format<?php echo esc_attr( $sticky_lclass ); ?>">
						<?php $t->seoaalCPTPortfolioFormat(); ?>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="portfolio-info<?php echo esc_attr( $sticky_rclass ); ?>">
						<?php $t->seoaalCPTPortfolioTitle(); ?>
						<?php $t->seoaalCPTPortfolioContent(); ?>
						<?php $t->seoaalCPTMeta(); ?>
						<?php $t->seoaalPortfolioNav(); ?>
					</div>
				</div><!-- .col -->
		
			</div><!-- .row -->
		</div><!-- .portfolio-single -->
	<?php endif; 
	
	//Portfolio Related Slider
	$t->seoaalCPTPortfolioRelated();
	
endwhile; // End of the loop.