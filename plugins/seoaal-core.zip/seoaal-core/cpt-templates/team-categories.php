<?php
// Team Archive Template
$q_object = get_queried_object();
$term_name = $taxonomy = '';
if( isset( $q_object->name ) ) $term_name = $q_object->name;
if( isset( $q_object->taxonomy ) ) $taxonomy = $q_object->taxonomy;
?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main archive-template" role="main">
						
			<?php
			$args = array(
				'post_type' => 'seoaal-team',
				$taxonomy 	=> $term_name
			);
			$query = new WP_Query( $args );
			
			if ( $query->have_posts() ) {
				
				echo '<div class="row">';
				
				// Start the Loop
				while ( $query->have_posts() ) : $query->the_post(); ?>
				
					<div class="col-md-6">
					
						<article id="post-<?php the_ID(); ?>" <?php post_class( 'post seoaal-team' ); ?>>
							<div class="team-archive">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium', array( 'class' => 'img-fluid' ) ); ?></a>
								<div class="team-archive-title">
									<h4><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php the_title(); ?></a></h4>
								</div>
							</div>
						</article><!-- #post-## -->
					
					</div><!-- .col-md-4 -->
				 
				<?php endwhile;
				
				echo '</div><!-- .row -->';
					 
			} // end of check for query having posts
				 
			// use reset postdata to restore orginal query
			wp_reset_postdata();
?>
		</main>
	</div>