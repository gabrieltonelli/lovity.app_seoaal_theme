<?php

/**

 * Template coming soon default

 */

 

 //get maintenance header

 require_once( SEOAAL_CORE_DIR . 'maintenance/header.php' );

 

 $seoaal_option = get_option( 'seoaal_options' );

 $address = isset( $seoaal_option['maintenance-address'] ) ? $seoaal_option['maintenance-address'] : '';

 $email = isset( $seoaal_option['maintenance-email'] ) ? $seoaal_option['maintenance-email'] : '';

 $phone = isset( $seoaal_option['maintenance-phone'] ) ? $seoaal_option['maintenance-phone'] : '';

 

?>



<div class="container text-center maintenance-wrap">



	<div class="row">

		<div class="col-md-12">

			<h1 class="maintenance-title"><?php esc_html_e( 'Under Maintenance', 'seoaal-core' ); ?></h1>

		</div>

	</div>



	<div class="row">

		<div class="col-md-4">

			<h4><?php esc_html_e( 'Phone', 'seoaal-core' ); ?></h4>

			<div class="maintenance-phone">

				<?php echo esc_html(  $phone ); ?>

			</div>

		</div>

		<div class="col-md-4">

			<h4><?php esc_html_e( 'Address', 'seoaal-core' ); ?></h4>

			<div class="maintenance-address">

				<?php echo wp_kses_post( $address ); ?>

			</div>

		</div>

		<div class="col-md-4">

			<h4><?php esc_html_e( 'Email', 'seoaal-core' ); ?></h4>

			<div class="maintenance-email">

				<?php echo esc_html(  $email ); ?>

			</div>

		</div>

	</div>

	

	<div class="row">

		<div class="col-md-12 maintenance-footer">

			<p><?php esc_html_e( 'We are currently in maintenance mode. We will be back soon.', 'seoaal-core' ); ?></p>

		</div>

	</div>

	

</div>



<?php

 //get maintenance header

 require_once( SEOAAL_CORE_DIR . 'maintenance/footer.php' );

?>