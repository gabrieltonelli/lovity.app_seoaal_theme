<?php
class SeoaalShortcodes {
	
	public function __construct(){
		add_shortcode( 'soundcloud', array( $this, 'seoaalSoundcloud' ) );
		add_shortcode( 'videoframe', array( $this, 'seoaalVideoIframe' ) );
		add_shortcode( 'video', array( $this, 'seoaalVideo' ) );
		add_shortcode( 'videoframenon', array( $this, 'seoaalVideoIframeNonParam' ) );
		add_shortcode( 'popup_anything', array( $this, 'seoaalPopupAnything' ) );
    }

	public function seoaalSoundcloud( $atts ) {
		$atts = shortcode_atts( array(
			'url' => 'https://api.soundcloud.com/tracks/',
			'height' => '',
			'width' => '',
			'params' => ''
		), $atts );
		return '<iframe width="'. esc_attr( $atts['width'] ) .'" height="'. esc_attr( $atts['height'] ) .'" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url='. esc_url( $atts['url'] ) .'&amp;'. esc_url( $atts['params'] ) .'"></iframe>';
	}
	
	public function seoaalVideoIframe( $atts ) {
		$atts = shortcode_atts( array(
			'url' => '',
			'height' => '',
			'width' => '',
			'params' => ''
		), $atts );
		
		$params = isset( $params ) && !empty( $params ) ? '?'. $params : '';

		return '<iframe width="'. esc_attr( $atts['width'] ) .'" height="'. esc_attr( $atts['height'] ) .'" src="'. esc_url( $atts['url'] ) .'?'. esc_attr( $atts['params'] ) .'"></iframe>';
	}
	
	
	public function seoaalVideoIframeNonParam( $atts ) {
		$atts = shortcode_atts( array(
			'url' => '',
			'height' => '',
			'width' => '',
			'params' => '',
			'allowfullscreen' => ''
		), $atts );
		return '<iframe width="'. esc_attr( $atts['width'] ) .'" height="'. esc_attr( $atts['height'] ) .'" src="'. esc_url( $atts['url'] ) .'?'. esc_attr( $atts['params'] ) .'" '. esc_attr( $atts['allowfullscreen'] ) .'></iframe>';
	}
	
	public function seoaalVideo( $atts ) {
		$atts = shortcode_atts( array(
			'url' => '',
			'height' => '',
			'width' => '',
		), $atts );
		
		return '<video class="seoaal-custom-video" width="'. esc_attr( $atts['width'] ) .'" height="'. esc_attr( $atts['height'] ) .'" preload="true" style="max-width:100%;">
                    <source src="'. esc_url( $atts['url'] ) .'" type="video/mp4">
                </video>';
	}
	
	//[popup_anything icon_class="icon-control-play" video_url="https://www.youtube.com/watch?v=-hTVNidxg2s" img_url=""]
	public function seoaalPopupAnything( $atts ) {
	
		wp_enqueue_script( 'jquery-magnific' );
		wp_enqueue_style( 'magnific-popup' );
	
		$atts = shortcode_atts( array(
			'icon_class' => 'fa fa-play-circle-o',
			'video_url' => 'https://www.youtube.com/watch?v=-hTVNidxg2s',
			'img_url' => ''
		), $atts );
		
		extract($atts);
		$output = '';
		if( $video_url ){
			$output = '<a class="popup-video-post" href="'. esc_url( $video_url ) .'">';
				if( $img_url ){
					$output .= '<img src="'. esc_url( $img_url ) .'" alt="'. esc_attr__( 'Video Trigger', 'seoaal-core' ) .'">';
				}else{
					$output .= '<div class="video-play-icon text-center"><span class="'. esc_attr( $icon_class ) .'"></span></div>';
				}
			$output .= '</a>';
		}
		return $output;
	}
} // Shortcode class end
$seoaalsc = new SeoaalShortcodes;