<?php 
/*
	Plugin Name: Seoaal Core
	Plugin URI: http://zozothemes.com/
	Description: Core plugin for seoaal theme.
	Version: 1.0.3
	Author: zozothemes
	Author URI: http://zozothemes.com/
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$cur_theme = wp_get_theme();	
if ( $cur_theme->get( 'Name' ) != 'Seoaal' && $cur_theme->get( 'Name' ) != 'Seoaal Child' ){
	return;
}
define( 'SEOAAL_CORE_DIR', plugin_dir_path( __FILE__ ) );
define('SEOAAL_CORE_URL', plugin_dir_url( __FILE__ ) );
load_plugin_textdomain( 'seoaal-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
//Maintenance 
require_once( SEOAAL_CORE_DIR . 'maintenance/maintenance.php' );
require_once( SEOAAL_CORE_DIR . 'seoaal-redux.php' );
require_once( SEOAAL_CORE_DIR . 'admin/metabox/metaboxes/meta_box.php' );
require_once( SEOAAL_CORE_DIR . 'admin/metabox/inc/seoaal-metabox.php' );
// Seoaal Shortcode
require_once( SEOAAL_CORE_DIR . 'admin/shortcodes/shortcodes.php' );
// Seoaal Theme Custom Font Upload Option
require_once( SEOAAL_CORE_DIR . 'custom-font-code/custom-fonts.php' );
// Seoaal AQ Resizer
require_once( SEOAAL_CORE_DIR . 'inc/aq_resizer.php' );
// Seoaal Widgets
require_once( SEOAAL_CORE_DIR . 'widgets/about_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/ads_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/latest_post_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/popular_post_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/tab_post_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/author_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/contact_info_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/instagram_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/social_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/tweets_widget.php' );
require_once( SEOAAL_CORE_DIR . 'widgets/mailchimp_widget.php' );
// Custom Post Types
require_once( SEOAAL_CORE_DIR . 'cpt/cpt-class.php' );
// Category Meta Field
require_once( SEOAAL_CORE_DIR . 'inc/seoaal-category-meta.php' );
function seoaal_core_admin_scripts_method() {
	wp_enqueue_style( 'font-awesome', get_theme_file_uri( '/assets/css/font-awesome.css' ), array(), '4.7.0' );
	wp_enqueue_style( 'simple-line-icons', get_theme_file_uri( '/assets/css/simple-line-icons.css' ), array(), '1.0' );
	wp_enqueue_style( 'seoaal-core-custom-style', plugins_url( '/admin/assets/css/theme-custom.css' , __FILE__ ), false, '1.0.0' );
    wp_enqueue_script( 'seoaal-core-custom', plugins_url( '/admin/assets/js/theme-custom.js' , __FILE__ ), array( 'jquery' ) );
	
	//Admin Localize Script
	wp_localize_script('seoaal-core-custom', 'seoaal_core_admin_ajax_var', array(
		'admin_ajax_url' => admin_url('admin-ajax.php'),
		'font_nonce' => wp_create_nonce('seoaal-font-nounce'), 
		'process' => esc_html__( 'Processing', 'seoaal-core' ),
		'font_del_pbm' => esc_html__( 'Font Deletion Problem', 'seoaal-core' )
	));
		
}
add_action( 'admin_enqueue_scripts', 'seoaal_core_admin_scripts_method' );
/*Author Social Links*/
if( ! function_exists('seoaal_author_contactmethods') ) {
	function seoaal_author_contactmethods( $contactmethods ) {
		$contactmethods['twitter'] = esc_html__('Twitter URL', 'seoaal-core');
		$contactmethods['facebook'] = esc_html__('Facebook URL', 'seoaal-core');
		$contactmethods['vimeo'] = esc_html__('Vimeo URL', 'seoaal-core');
		$contactmethods['youtube'] = esc_html__('Youtube URL', 'seoaal-core');
		
		return $contactmethods;
	}
	add_filter('user_contactmethods','seoaal_author_contactmethods',10,1);
}
/*Facebook Comments JS*/
if( ! function_exists('seoaal_fb_comments_js') ) {
	function seoaal_fb_comments_js(){
		$ato = new SeoaalThemeOpt;
		$comment_type = $ato->seoaalThemeOpt( 'comments-type' );
		if( $comment_type == 'fb' && is_single() ) :
			$fb_dev_api = $ato->seoaalThemeOpt( 'fb-developer-key' );
		?>
			<div id="fb-root"></div>
			<script>(function(d, s, id) {
			  var js, fjs = d.getElementsByTagName(s)[0];
			  if (d.getElementById(id)) return;
			  js = d.createElement(s); js.id = id;
			  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=<?php echo esc_attr( $fb_dev_api ); ?>";
			  fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>
		<?php
		endif;
	}
	add_action( 'seoaal_body_action', 'seoaal_fb_comments_js', 50 );
}
/* Add Admin Table Columns Head */
function seoaal_columns_head( $defaults ) {
	if ( current_user_can( 'manage_options' ) ) {
		$defaults['seoaal_post_featured_stat'] = esc_html__( 'Featured', 'seoaal-core' );
	}
    return $defaults;
}
add_filter('manage_post_posts_columns', 'seoaal_columns_head');
/* Add Admin Table Coulmn */
function seoaal_columns_content( $column_name, $post_ID ) {
	if ( current_user_can( 'manage_options' ) ) {
		if ( $column_name == 'seoaal_post_featured_stat' ) {
			$meta = get_post_meta( $post_ID, 'seoaal_post_featured_stat', true );
			$out = '<label class="seoaal-switch">
						<input type="checkbox" data-post="'.$post_ID.'" class="seoaal-post-featured-status" '. ( $meta == 1 ? 'checked' : '' ) .'>
						<div class="seoaal-slider round"></div>
					</label><br />
					<span id="post-featured-stat-msg-'.$post_ID.'"></span>';
			echo ( $out );
		}
	}
}
add_action('manage_post_posts_custom_column', 'seoaal_columns_content', 10, 2);
/* Active Featured Status */
add_action('wp_ajax_seoaal-post-featured-active', 'seoaal_post_featured_active');
function seoaal_post_featured_active(){
	$nonce = $_POST['nonce'];
  
    if ( ! wp_verify_nonce( $nonce, 'seoaal-post-featured' ) )
        die ( esc_html__( 'Busted!', 'seoaal-core' ) );
	
	update_post_meta( esc_attr( $_POST['postid'] ), 'seoaal_post_featured_stat', esc_attr($_POST['featured-stat']) );
	exit;
}
//Get server software
function seoaal_get_server_software(){
	return $_SERVER['SERVER_SOFTWARE'];
}
//Get remote address
function seoaal_get_remote_ip(){
	return $_SERVER['REMOTE_ADDR'];
}
//RTL Check
$seoaal_option = get_option( 'seoaal_options' );
$rtl = isset( $seoaal_option['rtl'] ) && $seoaal_option['rtl'] ? true : false;
if( $rtl ) add_filter( 'body_class','seoaal_rtl_body_classes' );
function seoaal_rtl_body_classes( $classes ) {
    $classes[] = 'rtl';
    return $classes;
}
// Facebook Share Code
//Adding the Open Graph in the Language Attributes
function seoaal_add_opengraph_doctype( $output ) {
	return $output . ' prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#"';
}
add_filter('language_attributes', 'seoaal_add_opengraph_doctype');
function seoaal_insert_fb_in_head() {
    global $post;
    if ( !is_singular()) //if it is not a post or a page
        return;
	
	ob_start();
	the_excerpt();
	$excerpt = ob_get_clean();	
	
	echo '<meta property="og:title" content="' . get_the_title() . '"/>
<meta property="og:type" content="article"/>
<meta property="og:url" content="' . esc_url( get_permalink() ) . '"/>
<meta property="og:site_name" content="'. get_bloginfo( 'name' ) .'"/>
<meta property="og:description" content="'. $excerpt .'"/>';
	
	if( has_post_thumbnail( $post->ID ) ) {
		$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'medium' );
		echo '
<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>
<meta property="og:image:width" content="' . esc_attr( $thumbnail_src[1] ) . '"/>
<meta property="og:image:height" content="' . esc_attr( $thumbnail_src[2] ) . '"/>
';
	}
	
    echo "";
}
add_action( 'wp_head', 'seoaal_insert_fb_in_head', 5 );
/* VC Shortcodes */
add_shortcode( 'seoaal_vc_circle_progress', 'seoaal_vc_circle_progress_shortcode' );
add_shortcode( 'seoaal_vc_compare_pricing', 'seoaal_vc_compare_pricing_shortcode' );
add_shortcode( 'seoaal_vc_content_carousel', 'seoaal_vc_content_carousel_shortcode' );
add_shortcode( 'seoaal_vc_counter', 'seoaal_vc_counter_shortcode' );
add_shortcode( 'seoaal_vc_day_counter', 'seoaal_vc_day_counter_shortcode' );
add_shortcode( 'seoaal_vc_events', 'seoaal_vc_events_shortcode' );
add_shortcode( 'seoaal_vc_feature_box', 'seoaal_vc_feature_box_shortcode' );
add_shortcode( 'seoaal_vc_flip_box', 'seoaal_vc_flip_box_shortcode' );
add_shortcode( 'seoaal_vc_google_map', 'seoaal_vc_google_map_shortcode' );
add_shortcode( 'seoaal_vc_icons', 'seoaal_vc_icons_shortcode' );
add_shortcode( 'seoaal_vc_mailchimp', 'seoaal_vc_mailchimp_shortcode' );
add_shortcode( 'seoaal_vc_modal_popup', 'seoaal_vc_modal_popup_shortcode' );
add_shortcode( 'seoaal_vc_portfolio', 'seoaal_vc_portfolio_shortcode' );
add_shortcode( 'seoaal_vc_blog', 'seoaal_vc_blog_shortcode' );
add_shortcode( 'seoaal_vc_blog_classic', 'seoaal_vc_blog_classic_shortcode' );
add_shortcode( 'seoaal_vc_pricing_table', 'seoaal_vc_pricing_table_shortcode' );
add_shortcode( 'seoaal_vc_section_title', 'seoaal_vc_section_title_shortcode' );
add_shortcode( 'seoaal_vc_services', 'seoaal_vc_services_shortcode' );
add_shortcode( 'seoaal_vc_social_icons', 'seoaal_vc_social_icons_shortcode' );
add_shortcode( 'seoaal_vc_team', 'seoaal_vc_team_shortcode' );
add_shortcode( 'seoaal_vc_testimonial', 'seoaal_vc_testimonial_shortcode' );
add_shortcode( 'seoaal_vc_timeline', 'seoaal_vc_timeline_shortcode' );
add_shortcode( 'seoaal_vc_timeline_slide', 'seoaal_vc_timeline_slide_shortcode' );
add_shortcode( 'seoaal_vc_twitter', 'seoaal_vc_twitter_shortcode' );
add_shortcode( 'seoaal_vc_image_grid', 'seoaal_vc_image_grid_shortcode' );
add_shortcode( 'seoaal_vc_contact_form', 'seoaal_vc_contact_form_shortcode' );
add_shortcode( 'seoaal_vc_contact_info', 'seoaal_vc_contact_info_shortcode' );
add_shortcode( 'seoaal_vc_list_item', 'seoaal_vc_list_item_shortcode' );
add_shortcode( 'seoaal_vc_portfolio_single', 'seoaal_vc_portfolio_single_shortcode' );
add_shortcode( 'seoaal_vc_button', 'seoaal_vc_button_shortcode' );
add_shortcode( 'seoaal_vc_tab', 'seoaal_vc_tab_shortcode' );
add_shortcode( 'seoaal_vc_tabs', 'seoaal_vc_tabs_shortcode' );
add_shortcode( 'seoaal_vc_cobbles', 'seoaal_vc_cobbles_shortcode' );
add_shortcode( 'seoaal_vc_schedule_box', 'seoaal_vc_schedule_box_shortcode' );
// Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');